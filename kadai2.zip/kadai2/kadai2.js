
function log(text){
	var label = document.getElementById('label');
				label.innerHTML = text;
}


document.getElementById("btn").onclick = function() {
	var num = document.forms.id_form1.id_textBox1.value;
	var r = isNaN(num)

	if(r){
  		log('エラー1');
	} else {
		num = parseInt(num);
  		if (num >= 2 && num <100){

  			var result = false;

		    //2 は素数なので true を返す
		    if(num === 2) {
		        result = true;
		    } else {
		    	
		        for(var i = 2; i < num; i++) {

		        //2以上の数で割ったとき余りが0になれば false を返す。つまり素数ではない。
		            if(num % i === 0) {
		                break;
		            }

		            //ループが最後まで行く、つまり割れる数がなかったら true を返す。つまり素数。
		            if(i + 1 === num) {
		                result = true;
		            }
		        }
		   }

		  	if(result){
	  			var label = document.getElementById('label')
				label.innerHTML = '素数です'
	  		}else{
	  			var label = document.getElementById('label')
				label.innerHTML = '素数じゃないです'
	  		}
		}else{
			var label = document.getElementById('label')
				label.innerHTML = 'エラー2'//数値2~100以外
		};
	}  
};
