
let number = 2;

while(number <= 100){
  console.log(number);
  number += 1;
}